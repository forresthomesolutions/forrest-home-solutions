Forrest Home Solutions website media update

3 before-and-after photos: gallery-photos/
2 new project videos: videos/

These files are ready to upload to the corresponding GitHub folders. The current live index.html is needed to merge them into your existing slideshow and video section without overwriting older photos or videos.
